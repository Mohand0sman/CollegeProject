let params = new URLSearchParams(window.location.search);
let id = params.get("id")
const basicUrl = "https://s-c-s.infinityfreeapp.com/api/articles"
const container = document.querySelector('.container');

fetch(`${basicUrl}?id=${id}`)
    .then((response) => {
        response.json();
    })
    .then((data) => {
       container.innerHTML = "";

       container.innerHTML = `
        <h2> ${data.title} </h2>
        <p class="des">
          ${data.description}
        </p>
        <hr>
        <p class="content">
            ${data.content}
        </p>
       `
    })
    .catch((error) => {
        console.log(error)
    })


function back(){
    window.location = 'index.html#explore'
}